-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 15, 2023 at 04:51 PM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ebill2`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `sno` int(100) NOT NULL,
  `name` varchar(100) NOT NULL,
  `username` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `role` varchar(100) NOT NULL,
  `status` varchar(100) NOT NULL DEFAULT 'pending'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`sno`, `name`, `username`, `email`, `password`, `role`, `status`) VALUES
(1, 'admin', 'admin', 'anoymaity1@gmail.com', '1234', '1', 'approved'),
(29, 'apk', 'apk', 'anoymaity0@gmail.com', '123', 'Add Admin', 'approved'),
(41, 'pocha', 'pocha', 'pocha@pocha.com', '123', 'complain', 'approved'),
(52, 'ola', 'ola', 'anoymaity0@gmail.com', '123', 'Bill', 'pending'),
(57, 'hhf', 'ffgg', 'anoymaity0@gmail.com', '12345678', 'User', 'approved');

-- --------------------------------------------------------

--
-- Table structure for table `bills`
--

CREATE TABLE `bills` (
  `sno` int(25) NOT NULL,
  `bid` varchar(100) NOT NULL,
  `cid` varchar(25) NOT NULL,
  `cname` varchar(25) NOT NULL,
  `unit` int(25) NOT NULL,
  `amount` int(25) NOT NULL,
  `bdate` date NOT NULL,
  `ddate` date NOT NULL,
  `status` varchar(100) NOT NULL DEFAULT 'pending',
  `payment_id` varchar(255) NOT NULL,
  `paytime` timestamp(6) NOT NULL DEFAULT current_timestamp(6) ON UPDATE current_timestamp(6)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `bills`
--

INSERT INTO `bills` (`sno`, `bid`, `cid`, `cname`, `unit`, `amount`, `bdate`, `ddate`, `status`, `payment_id`, `paytime`) VALUES
(47, 'BI01', 'CUS03', 'sourjya', 340, 2300, '2023-05-11', '2023-05-24', 'paid', 'pay_LoKnjibow1GaxG', '0000-00-00 00:00:00.000000'),
(48, 'BI02', 'CUS03', 'sourjya', 340, 2300, '2023-05-22', '2023-05-24', 'paid', 'pay_LoKnjibow1GaxG', '0000-00-00 00:00:00.000000'),
(49, 'BI03', 'CUS01', 'Anoy Maity', 320, 2100, '2023-05-11', '2023-05-24', 'paid', 'pay_LoL4rIMUWOiFmq', '2023-05-11 11:27:58.306557'),
(58, 'BI010', 'CUS01', 'Anoy Maity', 108, 556, '2023-05-13', '2023-06-05', 'paid', '', '2023-05-13 11:26:38.851690'),
(59, 'BI11', 'CUS01', 'Anoy Maity', 1202, 10920, '2023-05-26', '2023-05-29', 'paid', '', '2023-05-13 11:29:55.389210'),
(60, 'BI12', 'CUS01', 'Anoy Maity', 420, 3100, '2023-05-31', '2023-06-06', 'paid', '', '2023-05-13 11:33:28.019868'),
(61, 'BI13', 'CUS01', 'Anoy Maity', 122, 654, '2023-05-13', '2023-05-26', 'paid', 'pay_Lp8UrhvvRIDlww', '2023-05-13 11:48:33.573207'),
(62, 'BI14', 'CUS01', 'Anoy Maity', 320, 2100, '2023-05-13', '2023-05-31', 'paid', 'pay_Lp8YBJMIpwUdqi', '2023-05-13 11:51:42.084718'),
(63, 'BI15', 'CUS02', 'halu halu', 52, 260, '2023-05-13', '2023-05-30', 'paid', 'pay_Lp8bmGfTAshOQh', '2023-05-13 11:55:06.376545'),
(64, 'BI16', 'CUS02', 'halu halu', 340, 2300, '2023-05-13', '2023-05-29', 'paid', 'pay_Lp90umcyeSs9tM', '2023-05-13 12:18:53.909216'),
(65, 'BI17', 'CUS01', 'Anoy Maity', 23, 115, '2023-05-24', '2023-05-24', 'pending', '', '2023-05-13 12:22:01.593770'),
(66, 'BI18', 'CUS01', 'Anoy Maity', 246, 1522, '2023-05-25', '2023-06-06', 'pending', '', '2023-05-13 12:22:53.669636');

-- --------------------------------------------------------

--
-- Table structure for table `complain`
--

CREATE TABLE `complain` (
  `id` int(20) NOT NULL,
  `conid` varchar(100) NOT NULL,
  `name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `complaint` varchar(400) NOT NULL,
  `status` varchar(100) NOT NULL,
  `cid` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `complain`
--

INSERT INTO `complain` (`id`, `conid`, `name`, `email`, `complaint`, `status`, `cid`) VALUES
(20, '', 'Gourab Dhar', 'gourab@gmail.com', 'lokijuhygtfr', 'approved', 'CUS1'),
(21, '', 'Gourab Dhar', 'gourab@gmail.com', 'hgfdsawertyu', 'approved', 'CUS2'),
(22, '', 'Anoy Maity', 'anoymaity0@gmail.com', 'ffdfdd', 'approved', 'CUS3'),
(24, '', 'Anoy Maity', 'anoymaity0@gmail.com', 'akmmfbhh', 'pending', 'COM5'),
(25, 'CUS02', 'halu halu', 'halu@gmail.com', 'fhdhfhdhdh', 'pending', 'COM6');

-- --------------------------------------------------------

--
-- Table structure for table `resolution`
--

CREATE TABLE `resolution` (
  `sno` int(100) NOT NULL,
  `name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `complaint` varchar(100) NOT NULL,
  `resolution` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `resolution`
--

INSERT INTO `resolution` (`sno`, `name`, `email`, `complaint`, `resolution`) VALUES
(1, 'ketu', 'ketu@gmail.com', 'ghdhdggggg', 'helo guys '),
(2, 'Anoy Maity', 'anoymaity0@gmail.com', 'ffdfdd', 'gdgdgdgd'),
(3, 'Anoy Maity', 'anoymaity0@gmail.com', 'ffdfdd', 'gdgdgdgd'),
(4, 'Anoy Maity', 'anoymaity0@gmail.com', 'ffdfdd', 'sefwffsfsfsffffafa'),
(5, 'Anoy Maity', 'anoymaity0@gmail.com', 'ffdfdd', 'uurdhjdrtjdrthjdt');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `sno` int(100) NOT NULL,
  `cid` varchar(100) NOT NULL,
  `cname` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `phno` varchar(100) NOT NULL,
  `occupation` varchar(100) NOT NULL,
  `address` varchar(100) NOT NULL,
  `city` varchar(100) NOT NULL,
  `state` varchar(100) NOT NULL,
  `pincode` varchar(100) NOT NULL,
  `connection` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `datetime` timestamp(5) NOT NULL DEFAULT current_timestamp(5) ON UPDATE current_timestamp(5)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`sno`, `cid`, `cname`, `email`, `phno`, `occupation`, `address`, `city`, `state`, `pincode`, `connection`, `password`, `datetime`) VALUES
(1, 'CUS01', 'Anoy Maity', 'anoymaity0@gmail.com', '9073108721', 'gdxfbfgb', '61,Sovabazar Street', 'Kolkata', 'WB', '700005', 'Household', '123', '2023-05-09 05:39:36.25712'),
(2, 'CUS02', 'halu halu', 'halu@gmail.com', '664646464', 'ggff', 'rrer', 'gth', 'LA', '455456', 'Commercial', '123', '2023-05-06 15:14:54.00000'),
(6, 'CUS03', 'sourjya', 'banerjeesourjya1@gmail.com', '9073108721', 'ggff', '61,Sovabazar Street', 'Kolkata', 'WB', '700005', 'Household', '12345678', '2023-05-08 15:31:59.00000');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`sno`);

--
-- Indexes for table `bills`
--
ALTER TABLE `bills`
  ADD PRIMARY KEY (`sno`);

--
-- Indexes for table `complain`
--
ALTER TABLE `complain`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `resolution`
--
ALTER TABLE `resolution`
  ADD PRIMARY KEY (`sno`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`sno`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `sno` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=59;

--
-- AUTO_INCREMENT for table `bills`
--
ALTER TABLE `bills`
  MODIFY `sno` int(25) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=67;

--
-- AUTO_INCREMENT for table `complain`
--
ALTER TABLE `complain`
  MODIFY `id` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;

--
-- AUTO_INCREMENT for table `resolution`
--
ALTER TABLE `resolution`
  MODIFY `sno` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `sno` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
